#!/bin/bash
cd AD_code;
make Makefile;
cd ..;

cd tools;
make Makefile;